/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mdb;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

/**
 *
 * @author ivgratchev
 */
@MessageDriven(mappedName = "amqmsg", activationConfig = {
    @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge"),
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue")
})
public class NewMessageBean implements MessageListener {
    @Resource(mappedName = "amqres")
    private ConnectionFactory amqres;
    
    public NewMessageBean() {
    }
    
    @Override
    public void onMessage(Message message) {
        System.out.println(message);
        try {
            sendJMSMessageToReplyQueue("Test message", (Queue) message.getJMSReplyTo(), message.getJMSMessageID());
        } catch (JMSException ex) {
            Logger.getLogger(NewMessageBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private Message createJMSMessageForreplyQueue(Session session, Object messageData) throws JMSException {
        // TODO create and populate message to send
        TextMessage tm = session.createTextMessage();
        tm.setText(messageData.toString());
        return tm;
    }

    private void sendJMSMessageToReplyQueue(Object messageData, Queue replyTo, String messageId) throws JMSException {
        Connection connection = null;
        Session session = null;
        try {
            connection = amqres.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            MessageProducer messageProducer = session.createProducer(replyTo);
            Message message = createJMSMessageForreplyQueue(session, messageData);
            message.setJMSCorrelationID(messageId);
            messageProducer.send(message);
        } finally {
            if (session != null) {
                try {
                    session.close();
                } catch (JMSException e) {
                    Logger.getLogger(this.getClass().getName()).log(Level.WARNING, "Cannot close session", e);
                }
            }
            if (connection != null) {
                connection.close();
            }
        }
    }
}
