/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ssb;

import javax.ejb.Local;

/**
 *
 * @author ivgratchev
 */
@Local
public interface NewSessionBeanLocal {

    public void testSendMessage();
    
}
