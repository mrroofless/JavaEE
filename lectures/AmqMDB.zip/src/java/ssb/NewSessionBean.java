/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ssb;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

/**
 *
 * @author ivgratchev
 */
@Stateless
public class NewSessionBean implements NewSessionBeanLocal {
    @Resource(name = "amqmsg")
    private Queue amqmsg;
    @Resource(name = "amqres")
    private ConnectionFactory amqres;

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    private Message createJMSMessageForamqmsg(Session session, Object messageData) throws JMSException {
        // TODO create and populate message to send
        TextMessage tm = session.createTextMessage();
        tm.setText(messageData.toString());
        return tm;
    }

    private void sendJMSMessageToAmqmsg(Object messageData) throws JMSException {
        Connection connection = null;
        Session session = null;
        try {
            connection = amqres.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            MessageProducer messageProducer = session.createProducer(amqmsg);
            messageProducer.send(createJMSMessageForamqmsg(session, messageData));
        } finally {
            if (session != null) {
                try {
                    session.close();
                } catch (JMSException e) {
                    Logger.getLogger(this.getClass().getName()).log(Level.WARNING, "Cannot close session", e);
                }
            }
            if (connection != null) {
                connection.close();
            }
        }
    }

    public void testSendMessage() {
        try {
            sendJMSMessageToAmqmsg("Hello from SSB");
        } catch (JMSException ex) {
            Logger.getLogger(NewSessionBean.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
